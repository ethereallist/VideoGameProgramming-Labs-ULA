from src.powerup import PowerUp
from typing import TypeVar, Any

class GhostPowerUp(PowerUp):

    def take(self, play_state: TypeVar("playing")) -> None:
        play_state.bird.ghost_mode = True
        play_state.bird.ghost_timer = 5.0